import { Component } from '@angular/core';

@Component({
  selector: 'app-timebar',
  standalone: true,
  imports: [],
  templateUrl: './timebar.component.html',
  styleUrl: './timebar.component.css'
})
export class TimebarComponent {

}
