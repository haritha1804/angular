import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TimebarComponent } from "./timebar/timebar.component";
import { QuestionbarComponent } from "./questionbar/questionbar.component";
import { QuizcontainerComponent } from "./quizcontainer/quizcontainer.component";
import { EndComponent } from "./end/end.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, TimebarComponent, QuestionbarComponent, QuizcontainerComponent, EndComponent]
})
export class AppComponent {
  title = 'sample';
}
