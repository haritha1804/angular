import { Component } from '@angular/core';

@Component({
  selector: 'app-quizcontainer',
  standalone: true,
  imports: [],
  templateUrl: './quizcontainer.component.html',
  styleUrl: './quizcontainer.component.css'
})
export class QuizcontainerComponent {

}
