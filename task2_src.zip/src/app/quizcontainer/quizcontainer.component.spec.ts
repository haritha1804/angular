import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizcontainerComponent } from './quizcontainer.component';

describe('QuizcontainerComponent', () => {
  let component: QuizcontainerComponent;
  let fixture: ComponentFixture<QuizcontainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuizcontainerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuizcontainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
