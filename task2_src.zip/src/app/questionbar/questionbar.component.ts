import { Component } from '@angular/core';

@Component({
  selector: 'app-questionbar',
  standalone: true,
  imports: [],
  templateUrl: './questionbar.component.html',
  styleUrl: './questionbar.component.css'
})
export class QuestionbarComponent {

}
